"""H3 Studio - a simple web UI for MiniMax H3 video generation.

Run ComfyUI (with MiniMax H3 weights already in place), then start this app
and open the address it prints. See README.md for setup.

This project does not download model weights. You supply them yourself, under
the MiniMax H3 Community License - which is not available in every territory.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import gradio as gr

from h3_backend import (
    DEFAULT_RESOLUTION,
    MAX_DURATION_SEC,
    MODEL_HINTS,
    RESOLUTION_PRESETS,
    ComfyClient,
    SamplingSettings,
    concat_videos,
    ffmpeg_available,
    length_to_seconds,
    pick_default,
    select_quality_model_set,
    snap_length,
)
from h3_library import (
    list_video_assets,
    move_video_to_trash,
    resolve_video_asset,
    video_asset_choices,
)
from h3_prompt_guard import (
    analyze_prompt,
    build_face_replacement_template,
    plan_reference_images,
    reference_image_paths,
)
from h3_queue import Job, QueueManager
from h3_scenebatch import SceneBatchError, parse_scene_batch

APP_DIR = Path(__file__).resolve().parent
CONFIG_PATH = APP_DIR / "config.json"

STATUS_ICON = {
    "queued": "…",
    "running": "▶",
    "done": "✓",
    "error": "✗",
    "cancelled": "—",
}

LANGUAGE_NAMES = {"ru": "Русский", "en": "English"}

STUDIO_CSS = """
:root {
  --h3-ink: #162033;
  --h3-muted: #61708a;
  --h3-line: #dce2ea;
  --h3-canvas: #f5f7fb;
  --h3-indigo: #5965f2;
  --h3-teal: #0f9f91;
  --h3-amber: #d98316;
}
.gradio-container { max-width: 1500px !important; color: var(--h3-ink); }
#mode-guide {
  border: 1px solid #cdd3ff;
  border-left: 5px solid var(--h3-indigo);
  border-radius: 14px;
  background: linear-gradient(100deg, #f0f2ff, #f8fbff);
  padding: 12px 16px;
}
#prompt-stats { color: var(--h3-muted); font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
#active-queue, #ready-library {
  border: 1px solid var(--h3-line);
  border-radius: 16px;
  background: white;
}
#ready-library label { line-height: 1.35; }
#library-actions { gap: 10px; }
.h3-output-note { color: var(--h3-muted); font-size: 0.92rem; }
"""

PROMPT_ISSUES = {
    "ru": {
        "reference_prompt_requires_r2v": (
            "Этот промпт использует <Subject>/<Picture>, но выбран режим «Кадр → видео». "
            "Перейдите в «Референсы → видео»: иначе Picture 2 станет конечным кадром, "
            "а идентичность Picture 1 не будет закреплена."
        ),
        "missing_picture_references": "Промпт ссылается на Picture {highest}, но загружено изображений: {count}.",
        "missing_video_references": "Промпт ссылается на Video {highest}, но загружено видео: {count}.",
        "missing_audio_references": "Промпт ссылается на Audio {highest}, но загружено аудиореференсов: {count}.",
        "wrong_model_family": "Выбранная видеомодель не соответствует режиму. Studio остановила запуск до списания времени GPU.",
        "prompt_overloaded": (
            "Промпт содержит {words} слов. Он будет передан целиком, но для одного клипа это перегружено: "
            "оставьте один причинно связный эпизод, а detailed_description держите примерно в пределах 350–500 слов."
        ),
        "reference_images_not_named": "Референсы загружены, но промпт не называет их как <Picture 1>, <Picture 2> и т. д.",
    },
    "en": {
        "reference_prompt_requires_r2v": (
            "This prompt uses <Subject>/<Picture>, but Image to Video is selected. "
            "Switch to Reference to Video; otherwise Picture 2 becomes an end keyframe and Picture 1 identity is not locked."
        ),
        "missing_picture_references": "The prompt references Picture {highest}, but only {count} image(s) are uploaded.",
        "missing_video_references": "The prompt references Video {highest}, but only {count} video(s) are uploaded.",
        "missing_audio_references": "The prompt references Audio {highest}, but only {count} audio reference(s) are uploaded.",
        "wrong_model_family": "The selected model family does not match the mode. Studio stopped before spending GPU time.",
        "prompt_overloaded": (
            "This prompt contains {words} words. It will be sent in full, but that is overloaded for one clip; "
            "keep one causal beat and aim for roughly 350–500 words in detailed_description."
        ),
        "reference_images_not_named": "Reference images are uploaded but the prompt never names <Picture 1>, <Picture 2>, etc.",
    },
}

T = {
    "ru": {
        "subtitle": "Локальная студия генерации видео MiniMax H3",
        "language": "Язык",
        "prompt": "Промпт",
        "prompt_ph": (
            "Опишите сцену, движение, камеру и звук.\n\n"
            "H3 лучше работает с разбивкой по времени, например:\n"
            "[0.0-3.0s] Камера медленно приближается, начинается дождь...\n"
            "[3.0-6.0s] Героиня поворачивается к свету...\n"
            "Звук: тихое пианино, дальний гром."
        ),
        "duration": "Длительность (секунды)",
        "resolution": "Формат и качество",
        "mode_t2v": "Текст → видео",
        "mode_i2v": "Кадр → видео",
        "mode_r2v": "Референсы → видео",
        "mode_guide": (
            "**IDENTITY LOCK** · Герой/объект + отдельная локация = **«Референсы → видео»**. "
            "Режим «Кадр → видео» предназначен только для точного первого и, при необходимости, точного последнего кадра."
        ),
        "t2v_help": "Генерация только по текстовому описанию.",
        "i2v_help": (
            "Оживите точный начальный кадр. Второй файл здесь — точный КОНЕЧНЫЙ кадр, "
            "а не референс локации, стиля или другого объекта."
        ),
        "r2v_help": (
            "Основной режим: загрузите до 4 лиц/героев, до 4 референсов окружения и "
            "до 3 исходных видео. Studio сама назначит `<Picture 1…9>`; `<Video 1>` "
            "может задавать движение, мизансцену и актёров, чьи лица нужно заменить."
        ),
        "start_frame": "Точный первый кадр",
        "end_frame": "Точный последний кадр — не локация/стиль (необязательно)",
        "chain": "Продолжить предыдущий клип",
        "chain_info": "Взять последний кадр предыдущего клипа как старт следующего. Можно сразу поставить несколько сцен в очередь.",
        "ref_characters": "Лица / герои — до 4 фото (порядок = Subject 1, 2, 3, 4)",
        "ref_environments": "Окружение / костюм / стиль — до 4 фото",
        "ref_images": "Дополнительные изображения — общий лимит 9",
        "ref_map_empty": "**Карта референсов:** сначала идут лица/герои, затем окружение, затем дополнительные изображения.",
        "face_template": "Вставить шаблон замены лиц в Video 1",
        "face_template_info": "Создаёт редактируемый Ref2VA-промпт для 2 героев или для уже загруженного числа лиц.",
        "ref_video": "Video 1–3 — исходные видео: движение / сцена / актёры для замены лиц",
        "ref_audio": "Audio 1–3 — референсный звук / голос",
        "use_video_audio": "Использовать также звук из всех референсных видео",
        "ref_size": "Детализация референсов",
        "ref_size_info": "max лучше удерживает лицо и мелкие детали, но заметно медленнее.",
        "advanced": "Расширенные настройки",
        "steps": "Шаги",
        "steps_info": "20 шагов — базовый качественный режим. Больше шагов медленнее и не всегда даёт лучший результат.",
        "sampler": "Сэмплер",
        "scheduler": "Планировщик",
        "scheduler_info": "Для тяжёлых референсов beta или normal иногда лучше simple.",
        "seed": "Seed",
        "seed_info": "-1 выбирает новый случайный seed для каждого запуска.",
        "models": "**Профиль качества зафиксирован автоматически.** Точные BF16-веса выбираются по режиму и не могут быть случайно очищены.",
        "diffusion": "Видеомодель H3",
        "encoder": "Текстовый энкодер",
        "vvae": "Video VAE",
        "avae": "Audio VAE",
        "dtype": "Режим загрузки веса (BF16 = default)",
        "label": "Название сцены (необязательно)",
        "label_ph": "крыша, кадр 1",
        "add": "Добавить в очередь",
        "add_info": "Если очередь пуста, генерация начнётся сразу.",
        "queue": "Очередь",
        "active_queue": "Текущие задачи",
        "active_queue_info": "Выберите задачу, если хотите отменить именно её.",
        "ready_videos": "Готовые видео",
        "ready_videos_info": "Выберите ролик — он сразу откроется ниже.",
        "result": "Результат",
        "refresh": "Обновить",
        "cancel": "Отменить",
        "download": "Скачать MP4",
        "delete": "Удалить",
        "delete_note": "Удаление перемещает файл в локальную корзину Studio — его можно восстановить на сервере.",
        "select_video": "Выберите готовое видео выше.",
        "library_empty": "Готовых видео пока нет.",
        "deleted": "Видео перемещено в корзину Studio: {name}",
        "join": "Склеить все готовые клипы",
        "join_info": "Склеивает все успешные клипы по порядку в один файл.",
        "joined": "Склеенное видео",
        "frames_note": "{frames} кадров ({seconds:.2f} с при 24 fps)",
        "idle": "Готово к работе",
        "err_prompt": "Сначала введите промпт.",
        "err_models": "Не найдены все нужные модели. Проверьте веса MiniMax H3 в ComfyUI и перезапустите сервис.",
        "err_start": "Для режима «Кадр → видео» нужен начальный кадр или флажок «Продолжить предыдущий клип».",
        "err_refs": "Добавьте хотя бы один референс.",
        "err_ref_order": "Проверьте лимиты: не более 4 фото героев, 4 фото окружения и 9 изображений суммарно.",
        "err_ref_media": "MiniMax H3 принимает не более 3 референсных видео и 3 отдельных аудиореференсов.",
        "err_join_few": "Для склейки нужно минимум два готовых клипа.",
        "err_ffmpeg": "Для склейки нужен ffmpeg, но он не найден.",
        "missing_models": "> **ComfyUI не видит: {items}.** Приложение не скачивает веса и не тратит кредиты.",
        "failed": "ошибка",
        "batch_title": "📥 Пакет сцен (JSON) — необязательно",
        "batch_help": "Добавьте сразу целую последовательность сцен из JSON. Обычной работе это не мешает.",
        "batch_file": "JSON-файл со сценами",
        "batch_text": "…или вставьте JSON сюда",
        "batch_button": "Импортировать и добавить в очередь",
        "err_batch_empty": "Вставьте JSON или выберите файл.",
        "batch_queued": "Добавлено сцен: {n}.",
    },
    "en": {
        "subtitle": "Video generation UI for MiniMax H3",
        "language": "Language",
        "prompt": "Prompt",
        "prompt_ph": (
            "Describe the shot, the motion, and the audio.\n\n"
            "H3 responds well to a second-by-second breakdown, e.g.\n"
            "[0.0-3.0s] The camera pushes in as rain begins to fall...\n"
            "[3.0-6.0s] She turns toward the light...\n"
            "Audio: soft piano, distant thunder."
        ),
        "duration": "Duration (seconds)",
        "resolution": "Resolution",
        "mode_t2v": "Text to Video",
        "mode_i2v": "Image to Video",
        "mode_r2v": "Reference to Video",
        "mode_guide": (
            "**IDENTITY LOCK** · Character/object plus a separate location belongs in **Reference to Video**. "
            "Image to Video is only for an exact first frame and, optionally, an exact last frame."
        ),
        "t2v_help": "Generate from the prompt alone.",
        "i2v_help": (
            "Animate an exact first frame. The second file here is the exact LAST frame, "
            "not a location, style, or object reference."
        ),
        "r2v_help": (
            "Primary workflow: upload up to 4 faces/characters, up to 4 environment "
            "references, and up to 3 source videos. Studio assigns `<Picture 1…9>`; "
            "`<Video 1>` can supply motion, staging, and actors whose faces are replaced."
        ),
        "start_frame": "Exact first frame",
        "end_frame": "Exact last frame — not location/style (optional)",
        "chain": "Continue from the previous clip",
        "chain_info": (
            "Use the last frame of the clip before this one as the start "
            "frame. Queue several of these to build a long scene."
        ),
        "ref_characters": "Faces / characters — up to 4 images (order = Subject 1, 2, 3, 4)",
        "ref_environments": "Environment / costume / style — up to 4 images",
        "ref_images": "Extra images — 9 total maximum",
        "ref_map_empty": "**Reference map:** faces/characters first, then environment, then extra images.",
        "face_template": "Insert Video 1 face-replacement template",
        "face_template_info": "Creates an editable Ref2VA prompt for 2 characters or the number of faces already uploaded.",
        "ref_video": "Video 1–3 — source motion / scene / actors for face replacement",
        "ref_audio": "Audio 1–3 — reference sound / voice",
        "use_video_audio": "Also use all reference-video soundtracks",
        "ref_size": "Reference detail",
        "ref_size_info": "'max' keeps more identity detail but is several times slower.",
        "advanced": "Advanced settings",
        "steps": "Steps",
        "steps_info": "More steps means better coherence and longer renders. 20 is a good default.",
        "sampler": "Sampler",
        "scheduler": "Scheduler",
        "scheduler_info": "'beta' or 'normal' often beat 'simple' for reference-heavy prompts.",
        "seed": "Seed",
        "seed_info": "-1 picks a new random seed each run.",
        "models": "**Quality profile is locked automatically.** Exact BF16 weights follow the selected mode and cannot be cleared accidentally.",
        "diffusion": "Diffusion model",
        "encoder": "Text encoder",
        "vvae": "Video VAE",
        "avae": "Audio VAE",
        "dtype": "Weight loading mode (BF16 = default)",
        "label": "Label (optional)",
        "label_ph": "rooftop, shot 1",
        "add": "Add to queue",
        "add_info": "Runs immediately when nothing else is queued.",
        "queue": "Queue",
        "active_queue": "Active jobs",
        "active_queue_info": "Select a job to cancel that exact job.",
        "ready_videos": "Ready videos",
        "ready_videos_info": "Select a video to open it below.",
        "result": "Result",
        "refresh": "Refresh",
        "cancel": "Cancel",
        "download": "Download MP4",
        "delete": "Delete",
        "delete_note": "Delete moves the file to Studio's local trash so it can be recovered on the server.",
        "select_video": "Select a ready video above.",
        "library_empty": "No ready videos yet.",
        "deleted": "Video moved to Studio trash: {name}",
        "join": "Join all finished clips",
        "join_info": "Concatenates every successful clip, in order, into one file.",
        "joined": "Joined video",
        "frames_note": "{frames} frames ({seconds:.2f}s at 24fps)",
        "idle": "Idle",
        "err_prompt": "Please write a prompt first.",
        "err_models": (
            "Model files are missing. Put the MiniMax H3 weights where ComfyUI "
            "can see them, restart ComfyUI, then reload this page."
        ),
        "err_start": "Image to Video needs a start frame, or tick 'Continue from the previous clip'.",
        "err_refs": "Reference to Video needs at least one reference input.",
        "err_ref_order": "Check the limits: at most 4 character images, 4 environment images, and 9 images total.",
        "err_ref_media": "MiniMax H3 accepts at most 3 reference videos and 3 standalone audio references.",
        "err_join_few": "Need at least two finished clips to join.",
        "err_ffmpeg": "ffmpeg is required to join clips, but was not found.",
        "missing_models": (
            "> **No {items} found in ComfyUI.** Put the MiniMax H3 weights in "
            "place and restart — see the README. This app never downloads them "
            "for you."
        ),
        "failed": "failed",
        "batch_title": "📥 Bulk import (JSON) — plus-alpha, optional",
        "batch_help": (
            "Queue a whole multi-scene sequence at once from a JSON document - "
            "handy for having an LLM write the scenes for you. This is an extra, "
            "not required for normal use. Schema and a full example are in the "
            "README."
        ),
        "batch_file": "Scene batch JSON file",
        "batch_text": "...or paste JSON here instead",
        "batch_button": "Import & queue",
        "err_batch_empty": "Paste some JSON or choose a file first.",
        "batch_queued": "Queued {n} scene(s).",
    },
    "ja": {
        "subtitle": "MiniMax H3 動画生成UI",
        "language": "言語 / Language",
        "prompt": "プロンプト",
        "prompt_ph": (
            "映像・動き・音声を記述します。\n\n"
            "H3は秒単位の指定によく反応します。例:\n"
            "[0.0-3.0s] 雨が降り始め、カメラがゆっくり寄る...\n"
            "[3.0-6.0s] 彼女が光の方を振り向く...\n"
            "Audio: 静かなピアノ、遠くの雷鳴。"
        ),
        "duration": "長さ(秒)",
        "resolution": "解像度",
        "mode_t2v": "テキストから生成",
        "mode_i2v": "画像から生成",
        "mode_r2v": "参照から生成",
        "t2v_help": "プロンプトのみから生成します。",
        "i2v_help": "静止画を動かします。終了フレームも指定すると、2枚の間を補間します。",
        "r2v_help": (
            "参照素材からキャラクター・画風・動きを引き継ぎます。"
            "プロンプト内では `<Picture 1>`、`<Video 1>`、`<Audio 1>` のように"
            "参照します。ref2vaモデルが必要で、VRAM消費もかなり大きくなります。"
        ),
        "start_frame": "開始フレーム",
        "end_frame": "終了フレーム(任意)",
        "chain": "前のクリップから続ける",
        "chain_info": (
            "1つ前のクリップの最終フレームを開始フレームにします。"
            "これを並べてキューすれば長いシーンを作れます。"
        ),
        "ref_images": "参照画像(最大9枚)",
        "ref_video": "参照動画",
        "ref_audio": "参照音声",
        "use_video_audio": "参照動画の音声も使う",
        "ref_size": "参照の解像度",
        "ref_size_info": "'max' は同一性の再現が上がりますが数倍遅くなります。",
        "advanced": "詳細設定",
        "steps": "ステップ数",
        "steps_info": "多いほど破綻が減りますが時間がかかります。20が標準です。",
        "sampler": "サンプラー",
        "scheduler": "スケジューラー",
        "scheduler_info": "参照を多用する場合は 'beta' や 'normal' が 'simple' より良い傾向があります。",
        "seed": "シード",
        "seed_info": "-1 で毎回ランダムになります。",
        "models": "**モデルファイル** — ComfyUIから検出したものです。自動ダウンロードは行いません。",
        "diffusion": "拡散モデル",
        "encoder": "テキストエンコーダー",
        "vvae": "映像VAE",
        "avae": "音声VAE",
        "dtype": "重みの精度",
        "label": "ラベル(任意)",
        "label_ph": "屋上、カット1",
        "add": "キューに追加",
        "add_info": "他に実行中のものがなければすぐ生成が始まります。",
        "queue": "キュー",
        "result": "結果",
        "refresh": "更新",
        "clear": "完了分を消す",
        "cancel": "キャンセル",
        "cancel_id": "キャンセルするジョブID",
        "join": "完成クリップを全部つなげる",
        "join_info": "成功したクリップを順番に1本の動画へ連結します。",
        "joined": "連結した動画",
        "frames_note": "{frames} フレーム (24fpsで {seconds:.2f} 秒)",
        "idle": "待機中",
        "err_prompt": "先にプロンプトを入力してください。",
        "err_models": (
            "モデルファイルが見つかりません。MiniMax H3の重みをComfyUIから見える"
            "場所に配置し、ComfyUIを再起動してからこのページを再読み込みしてください。"
        ),
        "err_start": "画像から生成するには開始フレームが必要です(「前のクリップから続ける」でも可)。",
        "err_refs": "参照から生成するには参照素材が最低1つ必要です。",
        "err_join_few": "連結するには完成クリップが2本以上必要です。",
        "err_ffmpeg": "クリップの連結にはffmpegが必要ですが、見つかりませんでした。",
        "missing_models": (
            "> **{items} がComfyUIに見つかりません。** MiniMax H3の重みを配置して"
            "再起動してください(READMEを参照)。このアプリは重みを自動ダウンロード"
            "しません。"
        ),
        "failed": "失敗",
        "batch_title": "📥 一括インポート(JSON) — プラスアルファ機能・任意",
        "batch_help": (
            "複数シーンをまとめてJSONで記述してキューに一括投入できます。LLMに"
            "シーン構成を書かせる用途向けの、通常操作には不要な追加機能です。"
            "スキーマと完全なサンプルはREADMEにあります。"
        ),
        "batch_file": "シーンバッチJSONファイル",
        "batch_text": "…またはここに直接JSONを貼り付け",
        "batch_button": "インポートしてキューに追加",
        "err_batch_empty": "先にJSONを貼り付けるか、ファイルを選択してください。",
        "batch_queued": "{n} 件のシーンをキューに追加しました。",
    },
}

MISSING_NAMES = {
    "ru": {"diffusion": "видеомодель", "encoder": "текстовый энкодер", "vae": "VAE"},
    "en": {"diffusion": "diffusion model", "encoder": "text encoder", "vae": "VAE"},
    "ja": {"diffusion": "拡散モデル", "encoder": "テキストエンコーダー", "vae": "VAE"},
}


def load_config() -> dict:
    defaults = {
        "comfy_url": "http://127.0.0.1:8188",
        "output_dir": str(APP_DIR / "outputs"),
        "server_port": 7860,
        "share": False,
        "language": "en",
    }
    if CONFIG_PATH.is_file():
        try:
            defaults.update(json.loads(CONFIG_PATH.read_text(encoding="utf-8")))
        except (OSError, json.JSONDecodeError) as exc:
            print(f"[warn] Ignoring unreadable config.json: {exc}")
    return defaults


def build_ui(manager: QueueManager, client: ComfyClient, lang: str) -> gr.Blocks:
    lang = lang if lang in T else "en"
    t = T[lang]

    models = client.list_models()
    samplers = client.list_samplers()
    schedulers = client.list_schedulers()

    diffusion_opts = models["diffusion_models"]
    encoder_opts = models["text_encoders"]
    vae_opts = models["vae"]
    lora_opts = models.get("loras", [])
    patch_opts = models.get("model_patches", [])

    #: Components whose text changes with the language, paired with a function
    #: producing the keyword arguments to re-apply for a given language.
    translated: list[tuple[gr.components.Component, callable]] = []

    def tr(component, **keys):
        """Register a component so the language switcher can relabel it.

        ``keys`` maps a component property to a key in the translation table,
        e.g. ``tr(box, label="prompt", placeholder="prompt_ph")``.
        """
        translated.append(
            (component, lambda tt: {prop: tt[key] for prop, key in keys.items()})
        )
        return component

    def describe_frames(seconds: float, tt: dict) -> str:
        frames = snap_length(seconds)
        return tt["frames_note"].format(
            frames=frames, seconds=length_to_seconds(frames)
        )

    def missing_notice(tt: dict, code: str) -> str:
        names = MISSING_NAMES[code]
        missing = [
            names[key]
            for key, opts in (
                ("diffusion", diffusion_opts),
                ("encoder", encoder_opts),
                ("vae", vae_opts),
            )
            if not opts
        ]
        if not missing:
            return ""
        return tt["missing_models"].format(items="、".join(missing)
                                           if code == "ja" else ", ".join(missing))

    def model_inventory_notice(code: str) -> str:
        required = [
            MODEL_HINTS["fl2va"],
            MODEL_HINTS["ref2va"],
            MODEL_HINTS["text_encoder"],
            MODEL_HINTS["video_vae"],
            MODEL_HINTS["audio_vae"],
        ]
        all_core = diffusion_opts + encoder_opts + vae_opts
        found_required = [
            name for name in required
            if any(name.lower() in option.lower() for option in all_core)
        ]
        optional = [
            option for option in all_core
            if any(token in option.lower() for token in ("int8", "nvfp4"))
        ]
        if code == "ru":
            lines = [
                f"**Состояние весов: {len(found_required)}/5 обязательных готовы.**",
                "- Активный профиль: BF16 Ref2VA/FL2VA + BF16 Qwen3VL + FP16 Video VAE + FP32 Audio VAE.",
            ]
            if optional:
                lines.append("- Установлены оптимизированные веса: " + ", ".join(f"`{Path(x).name}`" for x in optional) + ".")
            if lora_opts:
                lines.append("- Установлены Turbo LoRA (не включены в профиль максимального качества): " + ", ".join(f"`{Path(x).name}`" for x in lora_opts) + ".")
            if patch_opts:
                lines.append("- Установлены H3 ControlNet-веса (отдельный workflow, не смешиваются с Ref2VA): " + ", ".join(f"`{Path(x).name}`" for x in patch_opts) + ".")
            return "\n".join(lines)
        lines = [
            f"**Weight status: {len(found_required)}/5 required files ready.**",
            "- Active profile: BF16 Ref2VA/FL2VA + BF16 Qwen3VL + FP16 Video VAE + FP32 Audio VAE.",
        ]
        if optional:
            lines.append("- Installed optimized weights: " + ", ".join(f"`{Path(x).name}`" for x in optional) + ".")
        if lora_opts:
            lines.append("- Installed Turbo LoRAs (not enabled in the maximum-quality profile): " + ", ".join(f"`{Path(x).name}`" for x in lora_opts) + ".")
        if patch_opts:
            lines.append("- Installed H3 ControlNet weights (a separate workflow, not mixed into Ref2VA): " + ", ".join(f"`{Path(x).name}`" for x in patch_opts) + ".")
        return "\n".join(lines)

    default_duration = 5.0

    with gr.Blocks(
        title="H3 Studio",
        theme=gr.themes.Soft(primary_hue="indigo", neutral_hue="slate"),
        css=STUDIO_CSS,
        analytics_enabled=False,
    ) as demo:
        lang_state = gr.State(lang)

        with gr.Row():
            header = gr.Markdown(
                f"## H3 Studio\n{t['subtitle']}  ·  Powered by MiniMax H3"
            )
            language = gr.Dropdown(
                choices=[(name, code) for code, name in LANGUAGE_NAMES.items()],
                value=lang,
                label=t["language"],
                scale=0,
                min_width=160,
            )
        tr(language, label="language")

        missing_md = gr.Markdown(
            missing_notice(t, lang), visible=bool(missing_notice(t, lang))
        )

        with gr.Row():
            # ---------------- controls ----------------
            with gr.Column(scale=3):
                mode_state = gr.State("r2v")
                mode_guide = tr(
                    gr.Markdown(t["mode_guide"], elem_id="mode-guide"),
                    value="mode_guide",
                )

                with gr.Tabs(selected="r2v"):
                    with gr.Tab(t["mode_t2v"], id="t2v") as tab_t2v:
                        tr(tab_t2v, label="mode_t2v")
                        tr(gr.Markdown(t["t2v_help"]), value="t2v_help")
                    with gr.Tab(t["mode_i2v"], id="i2v") as tab_i2v:
                        tr(tab_i2v, label="mode_i2v")
                        tr(gr.Markdown(t["i2v_help"]), value="i2v_help")
                        chain = tr(
                            gr.Checkbox(
                                label=t["chain"], value=False, info=t["chain_info"]
                            ),
                            label="chain", info="chain_info",
                        )
                        with gr.Row():
                            start_frame = tr(
                                gr.Image(
                                    label=t["start_frame"], type="filepath", height=200
                                ),
                                label="start_frame",
                            )
                            end_frame = tr(
                                gr.Image(
                                    label=t["end_frame"], type="filepath", height=200
                                ),
                                label="end_frame",
                            )
                    with gr.Tab(t["mode_r2v"], id="r2v") as tab_r2v:
                        tr(tab_r2v, label="mode_r2v")
                        tr(gr.Markdown(t["r2v_help"]), value="r2v_help")
                        with gr.Row():
                            ref_characters = tr(
                                gr.File(
                                    label=t["ref_characters"],
                                    file_count="multiple",
                                    file_types=["image"],
                                ),
                                label="ref_characters",
                            )
                            ref_environments = tr(
                                gr.File(
                                    label=t["ref_environments"],
                                    file_count="multiple",
                                    file_types=["image"],
                                ),
                                label="ref_environments",
                            )
                        ref_images = tr(
                            gr.File(
                                label=t["ref_images"],
                                file_count="multiple",
                                file_types=["image"],
                            ),
                            label="ref_images",
                        )
                        reference_map = gr.Markdown(t["ref_map_empty"])
                        face_template_btn = tr(
                            gr.Button(
                                t["face_template"],
                                variant="secondary",
                                size="sm",
                            ),
                            value="face_template",
                        )
                        face_template_note = tr(
                            gr.Markdown(f"<sub>{t['face_template_info']}</sub>"),
                            value="face_template_info",
                        )
                        with gr.Row():
                            ref_video = tr(
                                gr.File(
                                    label=t["ref_video"],
                                    file_count="multiple",
                                    file_types=["video"],
                                ),
                                label="ref_video",
                            )
                            ref_audio = tr(
                                gr.File(
                                    label=t["ref_audio"],
                                    file_count="multiple",
                                    file_types=["audio"],
                                ),
                                label="ref_audio",
                            )
                        with gr.Row():
                            use_video_audio = tr(
                                gr.Checkbox(label=t["use_video_audio"], value=True),
                                label="use_video_audio",
                            )
                            ref_size = tr(
                                gr.Radio(
                                    choices=["match", "max"],
                                    value="max",
                                    label=t["ref_size"],
                                    info=t["ref_size_info"],
                                ),
                                label="ref_size", info="ref_size_info",
                            )

                prompt = tr(
                    gr.Textbox(
                        label=t["prompt"],
                        placeholder=t["prompt_ph"],
                        lines=10,
                        max_lines=30,
                    ),
                    label="prompt", placeholder="prompt_ph",
                )
                prompt_stats = gr.Markdown(
                    (
                        "0 слов · 0 символов · полный текст будет отправлен без обрезки"
                        if lang == "ru"
                        else "0 words · 0 characters · the complete text will be sent without truncation"
                    ),
                    elem_id="prompt-stats",
                )

                with gr.Row():
                    duration = tr(
                        gr.Slider(
                            minimum=5.0,
                            maximum=MAX_DURATION_SEC,
                            value=default_duration,
                            step=0.5,
                            label=t["duration"],
                        ),
                        label="duration",
                    )
                    resolution = tr(
                        gr.Dropdown(
                            choices=list(RESOLUTION_PRESETS),
                            value=DEFAULT_RESOLUTION,
                            label=t["resolution"],
                        ),
                        label="resolution",
                    )
                frames_note = gr.Markdown(describe_frames(default_duration, t))

                with gr.Accordion(t["advanced"], open=False) as advanced_box:
                    tr(advanced_box, label="advanced")
                    with gr.Row():
                        steps = tr(
                            gr.Slider(
                                minimum=1, maximum=60, value=20, step=1,
                                label=t["steps"], info=t["steps_info"],
                            ),
                            label="steps", info="steps_info",
                        )
                        seed = tr(
                            gr.Number(
                                value=-1, precision=0,
                                label=t["seed"], info=t["seed_info"],
                            ),
                            label="seed", info="seed_info",
                        )
                    with gr.Row():
                        sampler = tr(
                            gr.Dropdown(
                                choices=samplers,
                                value="res_multistep" if "res_multistep" in samplers
                                else (samplers[0] if samplers else None),
                                label=t["sampler"],
                            ),
                            label="sampler",
                        )
                        scheduler = tr(
                            gr.Dropdown(
                                choices=schedulers,
                                value="simple" if "simple" in schedulers
                                else (schedulers[0] if schedulers else None),
                                label=t["scheduler"],
                                info=t["scheduler_info"],
                            ),
                            label="scheduler", info="scheduler_info",
                        )
                    tr(gr.Markdown(t["models"]), value="models")
                    model_inventory = gr.Markdown(
                        model_inventory_notice(lang), elem_id="model-inventory"
                    )
                    with gr.Row():
                        diffusion_model = tr(
                            gr.Dropdown(
                                choices=diffusion_opts,
                                value=pick_default(
                                    diffusion_opts, MODEL_HINTS["ref2va"]
                                ),
                                label=t["diffusion"],
                                interactive=False,
                            ),
                            label="diffusion",
                        )
                        text_encoder = tr(
                            gr.Dropdown(
                                choices=encoder_opts,
                                value=pick_default(
                                    encoder_opts, MODEL_HINTS["text_encoder"]
                                ),
                                label=t["encoder"],
                                interactive=False,
                            ),
                            label="encoder",
                        )
                    with gr.Row():
                        video_vae = tr(
                            gr.Dropdown(
                                choices=vae_opts,
                                value=pick_default(vae_opts, MODEL_HINTS["video_vae"]),
                                label=t["vvae"],
                                interactive=False,
                            ),
                            label="vvae",
                        )
                        audio_vae = tr(
                            gr.Dropdown(
                                choices=vae_opts,
                                value=pick_default(vae_opts, MODEL_HINTS["audio_vae"]),
                                label=t["avae"],
                                interactive=False,
                            ),
                            label="avae",
                        )
                    weight_dtype = tr(
                        gr.Dropdown(
                            choices=["default"],
                            value="default",
                            label=t["dtype"],
                            interactive=False,
                        ),
                        label="dtype",
                    )
                    label = tr(
                        gr.Textbox(label=t["label"], placeholder=t["label_ph"]),
                        label="label", placeholder="label_ph",
                    )

                add_btn = tr(
                    gr.Button(t["add"], variant="primary", size="lg"), value="add"
                )
                add_note = tr(gr.Markdown(f"<sub>{t['add_info']}</sub>"),
                              value="add_info")

            # ---------------- results ----------------
            with gr.Column(scale=2):
                status = gr.Markdown(t["idle"])
                active_queue = tr(
                    gr.Radio(
                        choices=[],
                        label=t["active_queue"],
                        info=t["active_queue_info"],
                        interactive=True,
                        elem_id="active-queue",
                    ),
                    label="active_queue", info="active_queue_info",
                )
                with gr.Row():
                    refresh_btn = tr(gr.Button(t["refresh"], size="sm"), value="refresh")
                    cancel_btn = tr(
                        gr.Button(t["cancel"], size="sm", variant="stop"),
                        value="cancel",
                    )

                initial_assets = list_video_assets(manager.output_dir)
                initial_asset = initial_assets[0] if initial_assets else None
                ready_videos = tr(
                    gr.Radio(
                        choices=video_asset_choices(initial_assets),
                        value=initial_asset.key if initial_asset else None,
                        label=t["ready_videos"],
                        info=t["ready_videos_info"],
                        interactive=True,
                        elem_id="ready-library",
                    ),
                    label="ready_videos", info="ready_videos_info",
                )
                result_video = tr(
                    gr.Video(
                        value=initial_asset.path if initial_asset else None,
                        label=t["result"],
                        height=320,
                    ),
                    label="result",
                )
                with gr.Row(elem_id="library-actions"):
                    download_btn = tr(
                        gr.DownloadButton(
                            t["download"],
                            value=initial_asset.path if initial_asset else None,
                            variant="primary",
                            interactive=bool(initial_asset),
                        ),
                        label="download",
                    )
                    delete_btn = tr(
                        gr.Button(
                            t["delete"],
                            variant="stop",
                            interactive=bool(initial_asset),
                        ),
                        value="delete",
                    )
                library_detail = gr.Markdown(
                    (
                        f"`{initial_asset.name}`  ·  {t['delete_note']}"
                        if initial_asset else t["library_empty"]
                    ),
                    elem_classes="h3-output-note",
                )
                join_btn = tr(gr.Button(t["join"]), value="join")
                join_note = tr(gr.Markdown(f"<sub>{t['join_info']}</sub>"),
                               value="join_info")
                joined_video = tr(
                    gr.Video(label=t["joined"], height=240, visible=False),
                    label="joined",
                )

                with gr.Accordion(t["batch_title"], open=False) as batch_box:
                    tr(batch_box, label="batch_title")
                    tr(gr.Markdown(t["batch_help"]), value="batch_help")
                    batch_file = tr(
                        gr.File(label=t["batch_file"], file_types=[".json"]),
                        label="batch_file",
                    )
                    batch_text = tr(
                        gr.Textbox(label=t["batch_text"], lines=6, max_lines=20),
                        label="batch_text",
                    )
                    batch_btn = tr(gr.Button(t["batch_button"]), value="batch_button")
                    batch_status = gr.Markdown()

        # ---------------- behaviour ----------------

        def describe_prompt(text: str, code: str) -> str:
            analysis = analyze_prompt(
                text or "",
                mode="t2v",
                reference_image_count=0,
                diffusion_model=None,
            )
            if code == "ru":
                return (
                    f"{analysis.word_count} слов · {analysis.character_count} символов · "
                    "полный текст будет отправлен без обрезки"
                )
            return (
                f"{analysis.word_count} words · {analysis.character_count} characters · "
                "the complete text will be sent without truncation"
            )

        prompt.input(describe_prompt, [prompt, lang_state], prompt_stats)

        duration.change(
            lambda seconds, code: describe_frames(seconds, T[code]),
            [duration, lang_state],
            frames_note,
        )

        for tab, name, model_hint in (
            (tab_t2v, "t2v", MODEL_HINTS["fl2va"]),
            (tab_i2v, "i2v", MODEL_HINTS["fl2va"]),
            (tab_r2v, "r2v", MODEL_HINTS["ref2va"]),
        ):
            tab.select(
                lambda n=name, hint=model_hint: (
                    n,
                    gr.update(value=pick_default(diffusion_opts, hint)),
                ),
                None,
                [mode_state, diffusion_model],
            )

        def describe_reference_map(
            characters, environments, extras, videos, audios, code: str
        ) -> str:
            tt = T.get(code, T["en"])
            try:
                plan = plan_reference_images(characters, environments, extras)
            except ValueError:
                return f"> ⚠️ {tt['err_ref_order']}"
            if not plan.assignments and not (videos or audios):
                return tt["ref_map_empty"]
            role_names = {
                "ru": {
                    "character": "герой / лицо",
                    "environment": "окружение / костюм / стиль",
                    "extra": "дополнительный референс",
                },
                "en": {
                    "character": "character / face",
                    "environment": "environment / costume / style",
                    "extra": "extra reference",
                },
            }["ru" if code == "ru" else "en"]
            heading = "**Карта референсов:**" if code == "ru" else "**Reference map:**"
            lines = [heading]
            for item in plan.assignments:
                filename = Path(item.path).name
                lines.append(
                    f"- `<Picture {item.picture_index}>` — "
                    f"{role_names[item.role]} {item.role_index}: `{filename}`"
                )
            for index, value in enumerate(videos or [], start=1):
                filename = Path(value.name if hasattr(value, "name") else str(value)).name
                lines.append(f"- `<Video {index}>` — `{filename}`")
            for index, value in enumerate(audios or [], start=1):
                filename = Path(value.name if hasattr(value, "name") else str(value)).name
                lines.append(f"- `<Audio {index}>` — `{filename}`")
            return "\n".join(lines)

        reference_inputs = [
            ref_characters,
            ref_environments,
            ref_images,
            ref_video,
            ref_audio,
            lang_state,
        ]
        for component in (
            ref_characters,
            ref_environments,
            ref_images,
            ref_video,
            ref_audio,
        ):
            component.change(
                describe_reference_map,
                reference_inputs,
                reference_map,
            )

        def insert_face_template(characters, environments, code: str):
            character_count = len(characters or []) or 2
            environment_count = len(environments or [])
            template = build_face_replacement_template(
                character_count=character_count,
                environment_count=environment_count,
                language=code,
            )
            return template, describe_prompt(template, code)

        face_template_btn.click(
            insert_face_template,
            [ref_characters, ref_environments, lang_state],
            [prompt, prompt_stats],
        )

        def snapshot(code: str):
            tt = T.get(code, T["en"])
            jobs = manager.jobs()
            active_choices = []
            for job in jobs:
                if job.status not in ("queued", "running"):
                    continue
                name = job.label or job.prompt[:38].replace("\n", " ") or job.mode
                when = f"{job.elapsed():.0f}s" if job.started_at else "-"
                active_choices.append(
                    (
                        f"{STATUS_ICON.get(job.status, '?')}  {name} · {job.mode} · {when} · {job.id}",
                        job.id,
                    )
                )

            line = manager.status_line()
            if line == "Idle":
                line = tt["idle"]
            failed = [j for j in jobs if j.status == "error"]
            if failed:
                line += f"\n\n**{failed[-1].id} {tt['failed']}:** {failed[-1].error}"
            assets = list_video_assets(manager.output_dir)
            return (
                line,
                gr.update(choices=active_choices),
                gr.update(choices=video_asset_choices(assets)),
            )

        def enqueue(
            code, mode, prompt_text, seconds, resolution_key, steps_v, seed_v,
            sampler_v, scheduler_v, label_v, chain_v, start_v, end_v,
            ref_characters_v, ref_environments_v,
            ref_imgs_v, ref_vid_v, ref_aud_v, use_vid_audio_v, ref_size_v,
        ):
            tt = T.get(code, T["en"])
            if not (prompt_text or "").strip():
                raise gr.Error(tt["err_prompt"])

            # System weights are a server contract, not a user-editable prompt option.
            try:
                quality_models = select_quality_model_set(mode, models)
            except ValueError as exc:
                raise gr.Error(f"{tt['err_models']}\n\n{exc}") from exc
            diffusion_v = quality_models.diffusion_model
            if mode == "i2v" and not chain_v and not start_v:
                raise gr.Error(tt["err_start"])

            width, height = RESOLUTION_PRESETS[resolution_key]
            try:
                ref_paths = reference_image_paths(
                    ref_characters_v, ref_environments_v, ref_imgs_v
                )
            except ValueError as exc:
                raise gr.Error(tt["err_ref_order"]) from exc
            ref_video_paths = [
                f.name if hasattr(f, "name") else str(f) for f in (ref_vid_v or [])
            ]
            ref_audio_paths = [
                f.name if hasattr(f, "name") else str(f) for f in (ref_aud_v or [])
            ]
            if len(ref_video_paths) > 3 or len(ref_audio_paths) > 3:
                raise gr.Error(tt["err_ref_media"])
            if mode == "r2v" and not (ref_paths or ref_video_paths or ref_audio_paths):
                raise gr.Error(tt["err_refs"])

            analysis = analyze_prompt(
                prompt_text,
                mode=mode,
                reference_image_count=len(ref_paths),
                reference_video_count=len(ref_video_paths),
                reference_audio_count=len(ref_audio_paths),
                diffusion_model=diffusion_v,
            )
            issue_text = PROMPT_ISSUES.get(code, PROMPT_ISSUES["en"])
            if analysis.error_codes:
                messages = []
                for error in analysis.error_codes:
                    highest = analysis.highest_picture_index
                    count = len(ref_paths)
                    if error == "missing_video_references":
                        highest, count = analysis.highest_video_index, len(ref_video_paths)
                    elif error == "missing_audio_references":
                        highest, count = analysis.highest_audio_index, len(ref_audio_paths)
                    messages.append(
                        issue_text[error].format(
                            highest=highest,
                            count=count,
                            words=analysis.word_count,
                        )
                    )
                raise gr.Error("\n\n".join(messages))
            for warning in analysis.warning_codes:
                gr.Warning(
                    issue_text[warning].format(
                        highest=analysis.highest_picture_index,
                        count=len(ref_paths),
                        words=analysis.word_count,
                    )
                )

            manager.add(
                Job(
                    mode=mode,
                    prompt=prompt_text,
                    width=width,
                    height=height,
                    length=snap_length(seconds),
                    models=quality_models,
                    sampling=SamplingSettings(
                        steps=int(steps_v),
                        sampler=sampler_v,
                        scheduler=scheduler_v,
                        seed=int(seed_v),
                    ),
                    first_frame=start_v if mode == "i2v" else None,
                    last_frame=end_v if mode == "i2v" else None,
                    ref_images=ref_paths if mode == "r2v" else [],
                    ref_videos=ref_video_paths if mode == "r2v" else [],
                    ref_audios=ref_audio_paths if mode == "r2v" else [],
                    use_video_audio=bool(use_vid_audio_v),
                    ref_image_size=ref_size_v,
                    chain_from_previous=bool(chain_v) and mode == "i2v",
                    label=(label_v or "").strip(),
                )
            )
            return snapshot(code)

        add_inputs = [
            lang_state, mode_state, prompt, duration, resolution, steps, seed,
            sampler, scheduler, label, chain, start_frame, end_frame, ref_characters,
            ref_environments, ref_images, ref_video, ref_audio, use_video_audio, ref_size,
        ]
        live_outputs = [status, active_queue, ready_videos]

        add_btn.click(enqueue, add_inputs, live_outputs)
        refresh_btn.click(snapshot, lang_state, live_outputs)

        def do_cancel(job_id: str, code: str):
            if (job_id or "").strip():
                manager.cancel(job_id.strip())
            return snapshot(code)

        cancel_btn.click(do_cancel, [active_queue, lang_state], live_outputs)

        def select_video(asset_key: str | None, code: str):
            tt = T.get(code, T["en"])
            asset = resolve_video_asset(asset_key, manager.output_dir)
            if asset is None:
                return (
                    None,
                    gr.update(value=None, interactive=False),
                    gr.update(interactive=False),
                    tt["select_video"],
                )
            return (
                asset.path,
                gr.update(value=asset.path, interactive=True),
                gr.update(interactive=True),
                f"`{asset.name}`  ·  {tt['delete_note']}",
            )

        ready_videos.change(
            select_video,
            [ready_videos, lang_state],
            [result_video, download_btn, delete_btn, library_detail],
        )

        def delete_video(asset_key: str | None, code: str):
            tt = T.get(code, T["en"])
            asset = resolve_video_asset(asset_key, manager.output_dir)
            if asset is None:
                raise gr.Error(tt["select_video"])
            move_video_to_trash(asset.path, manager.output_dir)
            for job in manager.jobs():
                if job.output_path and Path(job.output_path).resolve() == Path(asset.path).resolve():
                    manager.remove_finished(job.id)
            line, active_update, _ = snapshot(code)
            line += f"\n\n{tt['deleted'].format(name=asset.name)}"
            assets = list_video_assets(manager.output_dir)
            return (
                line,
                active_update,
                gr.update(choices=video_asset_choices(assets), value=None),
                None,
                gr.update(value=None, interactive=False),
                gr.update(interactive=False),
                tt["deleted"].format(name=asset.name),
            )

        delete_btn.click(
            delete_video,
            [ready_videos, lang_state],
            [
                status,
                active_queue,
                ready_videos,
                result_video,
                download_btn,
                delete_btn,
                library_detail,
            ],
        )

        def do_join(code: str):
            tt = T.get(code, T["en"])
            done = manager.completed()
            if len(done) < 2:
                raise gr.Error(tt["err_join_few"])
            if not ffmpeg_available():
                raise gr.Error(tt["err_ffmpeg"])
            path = concat_videos(
                [j.output_path for j in done],
                Path(manager.output_dir) / "joined.mp4",
            )
            return gr.update(value=str(path), visible=True)

        join_btn.click(do_join, lang_state, joined_video)

        def do_batch_import(file_path: str | None, pasted: str, code: str):
            tt = T.get(code, T["en"])
            if file_path:
                text = Path(file_path).read_text(encoding="utf-8")
                base_dir = Path(file_path).resolve().parent
            elif (pasted or "").strip():
                text = pasted
                base_dir = Path.cwd()
            else:
                raise gr.Error(tt["err_batch_empty"])

            try:
                jobs, notes = parse_scene_batch(
                    text, base_dir, diffusion_opts, encoder_opts, vae_opts,
                    samplers, schedulers,
                )
            except SceneBatchError as exc:
                return f"```\n{exc}\n```"

            manager.add_batch(jobs)
            lines = [tt["batch_queued"].format(n=len(jobs))]
            lines.extend(f"- {note}" for note in notes)
            return "\n".join(lines)

        batch_btn.click(
            do_batch_import, [batch_file, batch_text, lang_state], batch_status
        )

        # ---------------- language switching ----------------

        def switch_language(code: str, seconds: float):
            code = code if code in T else "en"
            tt = T[code]
            updates = [gr.update(**build(tt)) for _, build in translated]
            notice = missing_notice(tt, code)
            return [
                code,
                f"## H3 Studio\n{tt['subtitle']}  ·  Powered by MiniMax H3",
                gr.update(value=notice, visible=bool(notice)),
                describe_frames(seconds, tt),
                model_inventory_notice(code),
                *updates,
            ]

        language.change(
            switch_language,
            [language, duration],
            [lang_state, header, missing_md, frames_note, model_inventory]
            + [component for component, _ in translated],
        )

        # Keep the queue view live while a job renders.
        gr.Timer(2.0).tick(snapshot, lang_state, live_outputs)

    return demo


def main() -> int:
    config = load_config()
    parser = argparse.ArgumentParser(description="H3 Studio")
    parser.add_argument("--comfy-url", default=config["comfy_url"])
    parser.add_argument("--output-dir", default=config["output_dir"])
    parser.add_argument("--port", type=int, default=config["server_port"])
    parser.add_argument("--lang", choices=sorted(LANGUAGE_NAMES), default=config["language"],
                        help="Starting interface language; switchable in the UI.")
    parser.add_argument("--listen", action="store_true",
                        help="Bind on the local network, not just this machine.")
    parser.add_argument(
        "--share", action="store_true", default=config["share"],
        help=(
            "Expose a temporary public Gradio URL that anyone on the internet "
            "can reach - not just your local network. WARNING: this app has no "
            "login, no region checks, and no content moderation built in, and "
            "the MiniMax H3 license imposes real obligations (safeguards, "
            "territorial limits, disclosures) on anyone who lets third parties "
            "generate Outputs through it. Making the model reachable like this "
            "without meeting those obligations yourself is on you. Not "
            "recommended for ordinary personal/local use."
        ),
    )
    args = parser.parse_args()

    if args.share:
        print(
            "\n"
            "[warning] --share will publish a public URL that anyone on the\n"
            "internet can open - this app has no login, no region checks, and\n"
            "no content moderation. If people outside the MiniMax H3 license's\n"
            "Applicable Territory can reach it, or if it is used as a public\n"
            "Hosted Service, you - not this project - are responsible for\n"
            "meeting the license's safeguard and territorial obligations.\n"
            "Prefer running locally (no --share) unless you understand and\n"
            "accept that.\n",
            file=sys.stderr,
        )

    client = ComfyClient(args.comfy_url)
    if not client.is_alive():
        print(
            f"Could not reach ComfyUI at {args.comfy_url}.\n"
            "Start ComfyUI first, or pass --comfy-url with the right address.",
            file=sys.stderr,
        )
        return 1
    if not client.has_h3_nodes():
        print(
            "This ComfyUI build does not have the MiniMax H3 nodes.\n"
            "Update ComfyUI to a version that includes them (0.30.0 or newer).",
            file=sys.stderr,
        )
        return 1
    if not ffmpeg_available():
        print("[warn] ffmpeg not found - clip chaining and joining will not work.")

    output_dir = Path(args.output_dir)
    manager = QueueManager(client, output_dir, output_dir / ".work")
    demo = build_ui(manager, client, args.lang)
    demo.queue().launch(
        server_name="0.0.0.0" if args.listen else "127.0.0.1",
        server_port=args.port,
        share=args.share,
        inbrowser=True,
        show_api=False,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
