"""Persistent output-library helpers for H3 Studio."""

from __future__ import annotations

import shutil
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


VIDEO_SUFFIXES = {".mp4", ".mov", ".mkv", ".webm"}


@dataclass(frozen=True)
class VideoAsset:
    key: str
    name: str
    path: str
    size_bytes: int
    modified_at: float


def list_video_assets(output_dir: str | Path) -> list[VideoAsset]:
    """List saved videos independently of the in-memory render queue."""
    root = Path(output_dir)
    if not root.is_dir():
        return []
    assets = []
    for path in root.iterdir():
        if not path.is_file() or path.suffix.lower() not in VIDEO_SUFFIXES:
            continue
        stat = path.stat()
        assets.append(
            VideoAsset(
                key=f"file:{path.name}",
                name=path.name,
                path=str(path),
                size_bytes=stat.st_size,
                modified_at=stat.st_mtime,
            )
        )
    return sorted(assets, key=lambda item: item.modified_at, reverse=True)


def _human_size(size_bytes: int) -> str:
    size = float(size_bytes)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} GB"


def video_asset_choices(assets: list[VideoAsset]) -> list[tuple[str, str]]:
    """Create readable radio choices whose values are stable library keys."""
    choices = []
    for asset in assets:
        modified = datetime.fromtimestamp(asset.modified_at).strftime("%d.%m.%Y %H:%M")
        short_id = Path(asset.name).stem.rsplit("_", 1)[-1]
        label = f"🎬 {modified} · {_human_size(asset.size_bytes)} · {short_id}"
        choices.append((label, asset.key))
    return choices


def resolve_video_asset(key: str | None, output_dir: str | Path) -> VideoAsset | None:
    """Resolve only a direct library key; never accept a caller-provided path."""
    if not key or not key.startswith("file:"):
        return None
    name = key.removeprefix("file:")
    if not name or Path(name).name != name:
        return None
    return next((asset for asset in list_video_assets(output_dir) if asset.key == key), None)


def move_video_to_trash(path: str | Path, output_dir: str | Path) -> Path:
    """Move one exact output into Studio's recoverable local trash."""
    output_path = Path(output_dir)
    root = output_path.resolve()
    candidate = Path(path).resolve()
    if candidate.parent != root:
        raise ValueError("Only files directly inside the Studio output directory can be removed.")
    if not candidate.is_file() or candidate.suffix.lower() not in VIDEO_SUFFIXES:
        raise ValueError("The selected Studio video does not exist.")

    trash_dir = output_path / ".trash"
    trash_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    destination = trash_dir / f"{stamp}_{candidate.name}"
    collision = 1
    while destination.exists():
        destination = trash_dir / f"{stamp}_{collision}_{candidate.name}"
        collision += 1
    shutil.move(str(candidate), str(destination))
    return destination
