"""Validate H3 prompt/reference contracts before an expensive render starts."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable


PICTURE_TAG = re.compile(r"<Picture\s+(\d+)>", re.IGNORECASE)
VIDEO_TAG = re.compile(r"<Video\s+(\d+)>", re.IGNORECASE)
AUDIO_TAG = re.compile(r"<Audio\s+(\d+)>", re.IGNORECASE)
REFERENCE_SCHEMA = re.compile(
    r"<Subject\s+\d+>|<(?:Picture|Video|Audio)\s+\d+>|^\s*(?:subject_definitions|retention_analysis)\s*:",
    re.IGNORECASE | re.MULTILINE,
)


@dataclass(frozen=True)
class PromptAnalysis:
    character_count: int
    word_count: int
    highest_picture_index: int
    highest_video_index: int
    highest_audio_index: int
    error_codes: tuple[str, ...]
    warning_codes: tuple[str, ...]


@dataclass(frozen=True)
class ReferenceAssignment:
    picture_index: int
    role: str
    role_index: int
    path: str


@dataclass(frozen=True)
class ReferencePlan:
    assignments: tuple[ReferenceAssignment, ...]

    @property
    def paths(self) -> tuple[str, ...]:
        return tuple(item.path for item in self.assignments)


def analyze_prompt(
    prompt: str,
    *,
    mode: str,
    reference_image_count: int = 0,
    reference_video_count: int = 0,
    reference_audio_count: int = 0,
    diffusion_model: str | None = None,
) -> PromptAnalysis:
    """Return structural errors and load warnings without rewriting the prompt."""
    prompt = prompt or ""
    picture_indices = [int(value) for value in PICTURE_TAG.findall(prompt)]
    video_indices = [int(value) for value in VIDEO_TAG.findall(prompt)]
    audio_indices = [int(value) for value in AUDIO_TAG.findall(prompt)]
    highest_picture = max(picture_indices, default=0)
    highest_video = max(video_indices, default=0)
    highest_audio = max(audio_indices, default=0)
    errors: list[str] = []
    warnings: list[str] = []

    has_reference_schema = bool(REFERENCE_SCHEMA.search(prompt))
    if mode != "r2v" and has_reference_schema:
        errors.append("reference_prompt_requires_r2v")
    if mode == "r2v" and highest_picture > reference_image_count:
        errors.append("missing_picture_references")
    if mode == "r2v" and highest_video > reference_video_count:
        errors.append("missing_video_references")
    if mode == "r2v" and highest_audio > reference_audio_count:
        errors.append("missing_audio_references")

    model_name = (diffusion_model or "").lower()
    if model_name:
        wrong_family = (mode == "r2v" and "ref2va" not in model_name) or (
            mode != "r2v" and "ref2va" in model_name
        )
        if wrong_family:
            errors.append("wrong_model_family")

    word_count = len(re.findall(r"\S+", prompt))
    if word_count > 900:
        warnings.append("prompt_overloaded")
    if mode == "r2v" and reference_image_count and highest_picture == 0:
        warnings.append("reference_images_not_named")

    return PromptAnalysis(
        character_count=len(prompt),
        word_count=word_count,
        highest_picture_index=highest_picture,
        highest_video_index=highest_video,
        highest_audio_index=highest_audio,
        error_codes=tuple(errors),
        warning_codes=tuple(warnings),
    )


def _upload_path(value: object | None) -> str | None:
    if value is None:
        return None
    name = getattr(value, "name", value)
    text = str(name).strip()
    return text or None


def _paths(values: Iterable[object] | None) -> list[str]:
    return [path for item in (values or []) if (path := _upload_path(item))]


def plan_reference_images(
    characters: Iterable[object] | None,
    environments: Iterable[object] | None,
    extras: Iterable[object] | None,
) -> ReferencePlan:
    """Assign stable Picture numbers across semantic upload groups."""
    groups = {
        "character": _paths(characters),
        "environment": _paths(environments),
        "extra": _paths(extras),
    }
    if len(groups["character"]) > 4:
        raise ValueError("Use no more than four character or face images.")
    if len(groups["environment"]) > 4:
        raise ValueError("Use no more than four environment images.")
    if sum(len(paths) for paths in groups.values()) > 9:
        raise ValueError("MiniMax H3 accepts no more than nine total reference images.")

    assignments = []
    picture_index = 1
    for role in ("character", "environment", "extra"):
        for role_index, path in enumerate(groups[role], start=1):
            assignments.append(
                ReferenceAssignment(
                    picture_index=picture_index,
                    role=role,
                    role_index=role_index,
                    path=path,
                )
            )
            picture_index += 1
    return ReferencePlan(tuple(assignments))


def reference_image_paths(
    characters: Iterable[object] | None,
    environments: Iterable[object] | None,
    extras: Iterable[object] | None,
) -> list[str]:
    """Build the exact Picture 1..9 order shown by the Studio UI."""
    return list(plan_reference_images(characters, environments, extras).paths)


def build_face_replacement_template(
    *, character_count: int, environment_count: int, language: str
) -> str:
    """Create an editable Ref2VA scaffold for replacing several video actors."""
    character_count = max(1, min(int(character_count or 0), 4))
    environment_count = max(0, min(int(environment_count or 0), 4))
    environment_start = character_count + 1

    if language == "ru":
        subjects = "\n".join(
            f"<Subject {index}> — точная идентичность героя из <Picture {index}>: "
            "сохранить лицо, форму головы, возраст, волосы и узнаваемые особенности без смешивания с другими героями."
            for index in range(1, character_count + 1)
        )
        replacements = "\n".join(
            f"- заменить исходного актёра {index} в <Video 1> на <Subject {index}>; "
            "сохранить тело, движение, тайминг и позицию актёра из видео, но не его лицо;"
            for index in range(1, character_count + 1)
        )
        environments = "\n".join(
            f"<Picture {index}> — референс окружения/костюма/стиля {index - environment_start + 1}."
            for index in range(environment_start, environment_start + environment_count)
        )
        return f"""subject_definitions:
{subjects}

reference_roles:
<Video 1> — единственный источник движения, актёрской игры, тайминга, мизансцены и камеры.
Не использовать лица исходных актёров из <Video 1> как референсы идентичности.
{environments}

replacement_map:
{replacements}

retention_analysis:
Каждый Subject сохраняет собственную идентичность во всех кадрах. Не смешивать лица, волосы, возраст или черты разных Subject. Не менять число людей. Не добавлять новых лиц.

detailed_description:
[Опишите один причинно связный эпизод, действие каждого героя и желаемый результат.]
Сохранить композицию, движение камеры и синхронизацию <Video 1>. Использовать окружение из указанных Picture только там, где это явно требуется. Реалистичная окклюзия, стабильные лица в поворотах и во время движения, без морфинга и подмены героев местами.

audio:
Сохранить синхронизацию исходного видео; отдельно укажите, нужно ли сохранить звук <Video 1>."""

    subjects = "\n".join(
        f"<Subject {index}> — exact identity from <Picture {index}>; preserve face, head shape, age, hair, and unique features without blending subjects."
        for index in range(1, character_count + 1)
    )
    replacements = "\n".join(
        f"- replace source actor {index} in <Video 1> with <Subject {index}>; keep the actor's body motion, timing, and position, but not the original face;"
        for index in range(1, character_count + 1)
    )
    environments = "\n".join(
        f"<Picture {index}> — environment/costume/style reference {index - environment_start + 1}."
        for index in range(environment_start, environment_start + environment_count)
    )
    return f"""subject_definitions:
{subjects}

reference_roles:
<Video 1> is the sole source for motion, performance, timing, staging, and camera.
Ignore the original actors' faces in <Video 1> as identity references.
{environments}

replacement_map:
{replacements}

retention_analysis:
Keep every Subject's identity separate in every frame. Do not blend faces, hair, age, or features. Do not change the number of people or add faces.

detailed_description:
[Describe one causal beat, each character's action, and the intended result.]
Preserve the composition, camera motion, and synchronization of <Video 1>. Use the named Picture environment references only where requested. Maintain realistic occlusion and stable faces through turns and movement, with no morphing or subject swaps.

audio:
Preserve source-video synchronization; state explicitly whether <Video 1> audio should remain."""
