import unittest

from h3_backend import (
    ModelSet,
    ReferenceInputs,
    SamplingSettings,
    build_reference_graph,
    select_quality_model_set,
)


class ReferenceGraphTests(unittest.TestCase):
    def setUp(self):
        self.models = ModelSet("ref2va", "encoder", "video-vae", "audio-vae")

    def test_builds_three_numbered_reference_videos_with_their_audio(self):
        graph = build_reference_graph(
            prompt="Use <Video 1>, <Video 2>, and <Video 3>.",
            width=864,
            height=480,
            length=124,
            models=self.models,
            sampling=SamplingSettings(),
            seed=7,
            refs=ReferenceInputs(
                videos=["one.mp4", "two.mp4", "three.mp4"],
                use_video_audio=True,
            ),
        )

        inputs = graph["6"]["inputs"]
        self.assertIn("ref_videos.ref_video_0", inputs)
        self.assertIn("ref_videos.ref_video_1", inputs)
        self.assertIn("ref_videos.ref_video_2", inputs)
        self.assertIn("ref_video_audios.ref_video_audio_0", inputs)
        self.assertIn("ref_video_audios.ref_video_audio_1", inputs)
        self.assertIn("ref_video_audios.ref_video_audio_2", inputs)
        loaded = [
            node["inputs"]["file"]
            for node in graph.values()
            if node["class_type"] == "LoadVideo"
        ]
        self.assertEqual(loaded, ["one.mp4", "two.mp4", "three.mp4"])

    def test_builds_nine_ordered_image_references_without_empty_slots(self):
        images = [f"picture-{index}.png" for index in range(1, 10)]
        graph = build_reference_graph(
            prompt="Use <Picture 1> through <Picture 9>.",
            width=864,
            height=480,
            length=124,
            models=self.models,
            sampling=SamplingSettings(),
            seed=7,
            refs=ReferenceInputs(images=images),
        )

        inputs = graph["6"]["inputs"]
        image_keys = sorted(
            key for key in inputs if key.startswith("ref_images.ref_image_")
        )
        self.assertEqual(
            image_keys,
            [f"ref_images.ref_image_{index}" for index in range(9)],
        )
        loaded = [
            node["inputs"]["image"]
            for node in graph.values()
            if node["class_type"] == "LoadImage"
        ]
        self.assertEqual(loaded, images)

    def test_empty_reference_groups_do_not_create_required_image_nodes(self):
        graph = build_reference_graph(
            prompt="Use only the reference video.",
            width=864,
            height=480,
            length=124,
            models=self.models,
            sampling=SamplingSettings(),
            seed=7,
            refs=ReferenceInputs(videos=["motion.mp4"]),
        )

        inputs = graph["6"]["inputs"]
        self.assertFalse(
            any(key.startswith("ref_images.ref_image_") for key in inputs)
        )
        self.assertFalse(
            any(node["class_type"] == "LoadImage" for node in graph.values())
        )

    def test_builds_three_numbered_standalone_audio_references(self):
        graph = build_reference_graph(
            prompt="Use the voices.",
            width=864,
            height=480,
            length=124,
            models=self.models,
            sampling=SamplingSettings(),
            seed=7,
            refs=ReferenceInputs(audios=["one.wav", "two.wav", "three.wav"]),
        )

        inputs = graph["6"]["inputs"]
        self.assertIn("ref_audios.ref_audio_0", inputs)
        self.assertIn("ref_audios.ref_audio_1", inputs)
        self.assertIn("ref_audios.ref_audio_2", inputs)

    def test_reference_video_limit_is_three(self):
        with self.assertRaisesRegex(ValueError, "three reference videos"):
            build_reference_graph(
                prompt="too many",
                width=864,
                height=480,
                length=124,
                models=self.models,
                sampling=SamplingSettings(),
                seed=7,
                refs=ReferenceInputs(videos=[f"{i}.mp4" for i in range(4)]),
            )

    def test_quality_profile_selects_exact_bf16_reference_weights(self):
        selected = select_quality_model_set(
            "r2v",
            {
                "diffusion_models": [
                    "minimax_h3_ref2va_pruned_int8_convrot.safetensors",
                    "minimax_h3_ref2va_bf16.safetensors",
                ],
                "text_encoders": [
                    "qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors",
                    "qwen3vl_32b_minimax_h3_bf16.safetensors",
                ],
                "vae": [
                    "minimax_h3_video_vae_int8_convrot.safetensors",
                    "minimax_h3_video_vae_fp16.safetensors",
                    "minimax_h3_audio_vae_fp32.safetensors",
                ],
            },
        )

        self.assertEqual(selected.diffusion_model, "minimax_h3_ref2va_bf16.safetensors")
        self.assertEqual(selected.text_encoder, "qwen3vl_32b_minimax_h3_bf16.safetensors")
        self.assertEqual(selected.video_vae, "minimax_h3_video_vae_fp16.safetensors")
        self.assertEqual(selected.audio_vae, "minimax_h3_audio_vae_fp32.safetensors")
        self.assertEqual(selected.weight_dtype, "default")

    def test_quality_profile_fails_if_exact_required_weight_is_missing(self):
        with self.assertRaisesRegex(ValueError, "minimax_h3_ref2va_bf16"):
            select_quality_model_set(
                "r2v",
                {
                    "diffusion_models": ["minimax_h3_ref2va_pruned_int8_convrot.safetensors"],
                    "text_encoders": ["qwen3vl_32b_minimax_h3_bf16.safetensors"],
                    "vae": [
                        "minimax_h3_video_vae_fp16.safetensors",
                        "minimax_h3_audio_vae_fp32.safetensors",
                    ],
                },
            )


if __name__ == "__main__":
    unittest.main()
