import os
import tempfile
import time
import unittest
from pathlib import Path

from h3_library import (
    list_video_assets,
    move_video_to_trash,
    resolve_video_asset,
    video_asset_choices,
)


class VideoLibraryTests(unittest.TestCase):
    def test_lists_supported_videos_newest_first_and_ignores_trash(self):
        with tempfile.TemporaryDirectory() as tmp:
            output_dir = Path(tmp)
            old_video = output_dir / "old.mp4"
            new_video = output_dir / "new.webm"
            ignored = output_dir / "notes.txt"
            trashed = output_dir / ".trash" / "gone.mp4"
            trashed.parent.mkdir()
            for path in (old_video, new_video, ignored, trashed):
                path.write_bytes(b"video")
            now = time.time()
            os.utime(old_video, (now - 20, now - 20))
            os.utime(new_video, (now - 5, now - 5))

            assets = list_video_assets(output_dir)

            self.assertEqual([asset.name for asset in assets], ["new.webm", "old.mp4"])
            self.assertEqual(assets[0].key, "file:new.webm")

    def test_move_to_trash_is_recoverable_and_exact(self):
        with tempfile.TemporaryDirectory() as tmp:
            output_dir = Path(tmp)
            keep = output_dir / "keep.mp4"
            target = output_dir / "target.mp4"
            keep.write_bytes(b"keep")
            target.write_bytes(b"target")

            trashed = move_video_to_trash(target, output_dir)

            self.assertFalse(target.exists())
            self.assertTrue(trashed.is_file())
            self.assertEqual(trashed.read_bytes(), b"target")
            self.assertTrue(keep.is_file())
            self.assertEqual(trashed.parent, output_dir / ".trash")

    def test_refuses_to_move_a_file_outside_the_output_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            output_dir = root / "outputs"
            output_dir.mkdir()
            outside = root / "outside.mp4"
            outside.write_bytes(b"outside")

            with self.assertRaises(ValueError):
                move_video_to_trash(outside, output_dir)

    def test_choices_are_clickable_values_not_table_rows(self):
        with tempfile.TemporaryDirectory() as tmp:
            output_dir = Path(tmp)
            video = output_dir / "20260924_111531_5c20cfbb.mp4"
            video.write_bytes(b"x" * 1536)

            choices = video_asset_choices(list_video_assets(output_dir))

            self.assertEqual(choices[0][1], "file:20260924_111531_5c20cfbb.mp4")
            self.assertIn("1.5 KB", choices[0][0])
            self.assertIn("5c20cfbb", choices[0][0])

    def test_resolve_video_asset_rejects_path_traversal(self):
        with tempfile.TemporaryDirectory() as tmp:
            output_dir = Path(tmp)
            (output_dir / "safe.mp4").write_bytes(b"safe")

            self.assertIsNone(resolve_video_asset("file:../safe.mp4", output_dir))
            self.assertEqual(
                resolve_video_asset("file:safe.mp4", output_dir).name,
                "safe.mp4",
            )


if __name__ == "__main__":
    unittest.main()
