import unittest

from h3_prompt_guard import (
    analyze_prompt,
    build_face_replacement_template,
    plan_reference_images,
    reference_image_paths,
)


class NamedUpload:
    def __init__(self, name: str):
        self.name = name


class PromptGuardTests(unittest.TestCase):
    def test_reference_schema_is_rejected_in_keyframe_mode(self):
        analysis = analyze_prompt(
            "subject_definitions:\n<Subject 1> is the cat from <Picture 1>.",
            mode="i2v",
            reference_image_count=0,
            diffusion_model="minimax_h3_fl2va_bf16.safetensors",
        )

        self.assertIn("reference_prompt_requires_r2v", analysis.error_codes)

    def test_missing_numbered_picture_is_rejected(self):
        analysis = analyze_prompt(
            "<Subject 1> is from <Picture 1>. The room is from <Picture 2>.",
            mode="r2v",
            reference_image_count=1,
            diffusion_model="minimax_h3_ref2va_bf16.safetensors",
        )

        self.assertIn("missing_picture_references", analysis.error_codes)
        self.assertEqual(analysis.highest_picture_index, 2)

    def test_missing_numbered_video_is_rejected(self):
        analysis = analyze_prompt(
            "Use <Video 1> for motion and <Video 2> for camera.",
            mode="r2v",
            reference_image_count=0,
            reference_video_count=1,
            diffusion_model="minimax_h3_ref2va_bf16.safetensors",
        )

        self.assertIn("missing_video_references", analysis.error_codes)
        self.assertEqual(analysis.highest_video_index, 2)

    def test_missing_numbered_audio_is_rejected(self):
        analysis = analyze_prompt(
            "Use the voice from <Audio 2>.",
            mode="r2v",
            reference_image_count=0,
            reference_audio_count=1,
            diffusion_model="minimax_h3_ref2va_bf16.safetensors",
        )

        self.assertIn("missing_audio_references", analysis.error_codes)
        self.assertEqual(analysis.highest_audio_index, 2)

    def test_wrong_model_family_is_rejected(self):
        analysis = analyze_prompt(
            "The cat from <Picture 1> walks into frame.",
            mode="r2v",
            reference_image_count=1,
            diffusion_model="minimax_h3_fl2va_bf16.safetensors",
        )

        self.assertIn("wrong_model_family", analysis.error_codes)

    def test_long_prompt_is_reported_without_modifying_it(self):
        prompt = " ".join(["motion"] * 901)
        analysis = analyze_prompt(
            prompt,
            mode="t2v",
            reference_image_count=0,
            diffusion_model="minimax_h3_fl2va_bf16.safetensors",
        )

        self.assertEqual(analysis.word_count, 901)
        self.assertEqual(analysis.character_count, len(prompt))
        self.assertIn("prompt_overloaded", analysis.warning_codes)

    def test_valid_reference_prompt_has_no_errors(self):
        analysis = analyze_prompt(
            "<Subject 1> is the exact cat from <Picture 1>. "
            "Use <Picture 2> only for the kitchen.",
            mode="r2v",
            reference_image_count=2,
            diffusion_model="minimax_h3_ref2va_bf16.safetensors",
        )

        self.assertEqual(analysis.error_codes, ())

    def test_reference_paths_keep_identity_and_environment_first(self):
        paths = reference_image_paths(
            [NamedUpload("identity.png")],
            ["environment.png"],
            [NamedUpload(f"extra-{i}.png") for i in range(7)],
        )

        self.assertEqual(paths[:3], ["identity.png", "environment.png", "extra-0.png"])
        self.assertEqual(len(paths), 9)

    def test_two_characters_and_four_environments_get_stable_picture_numbers(self):
        plan = plan_reference_images(
            ["hero-a.png", "hero-b.png"],
            ["room-a.png", "room-b.png", "room-c.png", "room-d.png"],
            [],
        )

        self.assertEqual(
            [(item.picture_index, item.role, item.role_index) for item in plan.assignments],
            [
                (1, "character", 1),
                (2, "character", 2),
                (3, "environment", 1),
                (4, "environment", 2),
                (5, "environment", 3),
                (6, "environment", 4),
            ],
        )

    def test_reference_plan_rejects_more_than_four_character_images(self):
        with self.assertRaisesRegex(ValueError, "four character"):
            plan_reference_images([f"hero-{i}.png" for i in range(5)], [], [])

    def test_reference_plan_rejects_more_than_nine_total_images(self):
        with self.assertRaisesRegex(ValueError, "nine total"):
            plan_reference_images(
                [f"hero-{i}.png" for i in range(4)],
                [f"room-{i}.png" for i in range(4)],
                ["extra-a.png", "extra-b.png"],
            )

    def test_face_replacement_template_maps_two_people_and_source_video(self):
        prompt = build_face_replacement_template(
            character_count=2,
            environment_count=1,
            language="ru",
        )

        self.assertIn("<Subject 1>", prompt)
        self.assertIn("<Picture 1>", prompt)
        self.assertIn("<Subject 2>", prompt)
        self.assertIn("<Picture 2>", prompt)
        self.assertIn("<Picture 3>", prompt)
        self.assertIn("<Video 1>", prompt)
        self.assertIn("лица исходных актёров", prompt)


if __name__ == "__main__":
    unittest.main()
