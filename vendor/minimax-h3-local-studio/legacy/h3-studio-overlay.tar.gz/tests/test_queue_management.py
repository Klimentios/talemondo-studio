import threading
import tempfile
import unittest
from pathlib import Path

from h3_backend import ModelSet, SamplingSettings
from h3_queue import Job, QueueManager


def make_job(status: str) -> Job:
    return Job(
        mode="t2v",
        prompt="test",
        width=864,
        height=480,
        length=124,
        models=ModelSet("model", "encoder", "video", "audio"),
        sampling=SamplingSettings(),
        status=status,
    )


class QueueManagementTests(unittest.TestCase):
    def setUp(self):
        self.manager = QueueManager.__new__(QueueManager)
        self.manager._lock = threading.Lock()

    def test_remove_finished_removes_only_the_selected_finished_job(self):
        done = make_job("done")
        other = make_job("done")
        self.manager._jobs = [done, other]

        removed = self.manager.remove_finished(done.id)

        self.assertTrue(removed)
        self.assertEqual([job.id for job in self.manager._jobs], [other.id])

    def test_remove_finished_keeps_running_job(self):
        running = make_job("running")
        self.manager._jobs = [running]

        removed = self.manager.remove_finished(running.id)

        self.assertFalse(removed)
        self.assertEqual([job.id for job in self.manager._jobs], [running.id])

    def test_save_output_skips_cached_input_media_before_generated_video(self):
        downloaded = []

        class FakeClient:
            def download_output(self, filename, subfolder, dest):
                downloaded.append((filename, subfolder, dest))
                return dest

        with tempfile.TemporaryDirectory() as directory:
            self.manager.client = FakeClient()
            self.manager.output_dir = Path(directory)
            job = make_job("running")
            outputs = {
                "input_video": {
                    "images": [
                        {
                            "filename": "reference.mp4",
                            "subfolder": "",
                            "type": "input",
                        }
                    ]
                },
                "save_video": {
                    "images": [
                        {
                            "filename": "generated.mp4",
                            "subfolder": "video",
                            "type": "output",
                        }
                    ]
                },
            }

            result = self.manager._save_output(outputs, job)

        self.assertEqual(result.name.split("_", 2)[-1], f"{job.id}.mp4")
        self.assertEqual(downloaded[0][0:2], ("generated.mp4", "video"))


if __name__ == "__main__":
    unittest.main()
